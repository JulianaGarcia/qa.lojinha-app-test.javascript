export const config = {
   
    user: 'julianacarolinag_hA7dC0',
    key: '5b41YQ9HE4EwfZYELWC7',
    hostname: 'hub.browserstack.com',
    specs: [
        './test/specs/**/*.js'
    ],
    exclude: [
       
    ],
   
    maxInstances: 10,
    capabilities: [{
        'bstack:options': {
            deviceName: 'Samsung Galaxy S22 Ultra',
            platformVersion: '12.0',
            platformName: 'android'
        }
    }],
    logLevel: 'info',
    bail: 0,
    waitforTimeout: 10000,
    connectionRetryTimeout: 120000,
    connectionRetryCount: 3,
    services: [
        ['browserstack', {
            app: 'bs://d5d7d34b6c5ec7a446cd358a171ad722687214e5', 
            testObservability: false,
            testObservabilityOptions:{
                user: '',
                key: ''
            },
            browserstackLocal: false
        }]
    ],
    framework: 'mocha',
    reporters: [['allure', {
        outputDir: 'report/android/',
        disableWebdriverStepsReporting: true, 
        disableWebdriverScreenshotReporting: false,
    }]],
    mochaOpts: {
        ui: 'bdd',
        timeout: 60000
    },
    afterTest: async function (test, context, { error, result, duration, passed, retries }) {
        await driver.saveScreenshot(`./report/android/${test.title}${new Date().getTime()}.png`)
    }

}
