import { $ } from '@wdio/globals'

export default class ListaDeProdutosPage {

    get lblListaDeProdutos () {
        return $('android=new UiSelector().text("Lista de Produtos")');
    } 

    get btnAdicionarProduto(){
        return $('android=new UiSelector().description("ADICIONAR PRODUTO")')
    }

    get btnExcluirProduto (){
        return $('android=new UiSelector().text("delete").instance(4)')
    }

    async clickAdicionarProduto(){
        await this.btnAdicionarProduto.click()
    }

    async obterTextoLblListaProdutos () {
        return await this.lblListaDeProdutos.getText()
    }

    async clickExcluirProduto () {
        await this.btnExcluirProduto.click()
    }
 
}


