import { $ } from '@wdio/globals'

export default class AdicionarComponentePage {
   
    get txtNomeComponente(){
        return $('android=new UiSelector().resourceId("componentenomeadicionar")')
    }

    get txtQtdComponente(){
        return $('android=new UiSelector().resourceId("componentequantidadeadicionar")')
    }

    get btnSalvarComponente(){
        return $('android=new UiSelector().description("SALVAR COMPONENTE")')
    }

    async preencherNomeComponente(nomeComponente){
        await this.txtNomeComponente.setValue(nomeComponente)
    }

    async preencherQtdComponente(qtdComponente){
        await this.txtQtdComponente.setValue(qtdComponente)
    }

    async clickSalvarComponente(){
        await this.btnSalvarComponente.click()
    }

    async adicionarComponente(nomeComponente, qtdComponente ){
        await this.preencherNomeComponente(nomeComponente)
        await this.preencherQtdComponente(qtdComponente)
        await this.clickSalvarComponente()
    }
   
 
}