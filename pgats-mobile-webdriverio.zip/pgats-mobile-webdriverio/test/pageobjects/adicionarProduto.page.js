import { $ } from '@wdio/globals'

export default class AdicionarProdutosPage {

    get txtNomeProduto () {
        return $('android=new UiSelector().resourceId("produtonome")');
    } 

    get txtValorProduto () {
        return $('android=new UiSelector().resourceId("produtovalor")');
    }

    get txtCoresProduto () {
        return $('android=new UiSelector().resourceId("produtocores")');
    }

    get btnSalvar () {
        return $('android=new UiSelector().resourceId("btn-salvar")')
    }

    async preencherNomeProduto(nome){
        await this.txtNomeProduto.setValue(nome)
    }

    async preencherValorProduto(valor){
        await this.txtValorProduto.setValue(valor)
    }

    async preencherCorProduto(cor){
        await this.txtCoresProduto.setValue(cor)
    }

    async clickBtnSalvar () {
        await this.btnSalvar.click()
    }

    async adicionarProduto (nome, cor, valor){
        await this.preencherNomeProduto(nome)
        await this.preencherCorProduto(cor)
        await this.preencherValorProduto(valor)
        await this.clickBtnSalvar()
    }

   
 
}