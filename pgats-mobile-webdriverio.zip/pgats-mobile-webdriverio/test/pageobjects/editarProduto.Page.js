import { $ } from '@wdio/globals'

export default class EditarProdutosPage {

    get btnSalvarEdicao(){
        return $('//android.widget.Button[@text="SALVAR"]')
    }

    get btnAdicionarComponente(){
        return $('android=new UiSelector().description("ADICIONAR COMPONENTE")')
    }

    get btnExcluirComponente () {
        return $('android=new UiSelector().text("delete")')
    }

    get btnListaDeProdutos (){
        return $('android=new UiSelector().description("LISTA DE PRODUTOS")')
    }

    async clickSalvarEdicao () {
        await this.btnSalvarEdicao.click()
    }

    async clickAdicionarComponente(){
        await this.btnAdicionarComponente.click()
    }

    async clickExcluirComponente (){
        await this.btnExcluirComponente.click()
    }

    async clickListaDeProdutos () {
        await this.btnListaDeProdutos.click()
    }

    get lblMensagemEditadoSuceddo () {
        return $('android=new UiSelector().text("Componente de produto removido com sucesso")');
    } 

      async obterMensagemEditadoSucesso () {
        return await this.lblMensagemEditadoSuceddo.getText()
    }
 
     

}