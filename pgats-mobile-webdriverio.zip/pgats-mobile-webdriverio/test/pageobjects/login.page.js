import { $ } from '@wdio/globals'
import ListaDeProdutosPage from './listaDeProdutos.page';

export default class LoginPage {

    get txtUsuario () {
        return $('android=new UiSelector().resourceId("usuario")');
    }
    get txtSenha () {
        return $('//android.view.View[@text="Senha"]/../android.widget.EditText')
    }
    get btnEntrar () {
        return $('android=new UiSelector().resourceId("btn-entrar")')
    }

    async clickBtnEntrar() {
        await this.btnEntrar.click()
    }

    async preencherTxtUsuario(usuario) {
        await this.txtUsuario.setValue(usuario)    
    }

    async preenherTxtSenha(senha) {
        await this.txtSenha.setValue(senha)
    }

    async logarNaLojinha(usuario, senha) {
        await this.preencherTxtUsuario(usuario)
        await this.preenherTxtSenha(senha)
        await this.clickBtnEntrar()

    }

     async logarNaLojinhaComFluentPage(usuario, senha) {
        await this.preencherTxtUsuario(usuario)
        await this.preenherTxtSenha(senha)
        await this.clickBtnEntrar()
    }
 
}

