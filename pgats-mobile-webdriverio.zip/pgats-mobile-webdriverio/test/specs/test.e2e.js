import { expect } from '@wdio/globals'
import LoginPage from '../pageobjects/login.page.js'
import ListaDeProdutosPage from '../pageobjects/listaDeProdutos.page.js'
import AdicionarProdutosPage from '../pageobjects/adicionarProduto.page.js'
import EditarProdutosPage from '../pageobjects/editarProduto.Page.js'
import AdicionarComponentePage from '../pageobjects/adicionarComponente.page.js'

describe('Lojinha App', () => {
    const usuario = 'admin'
    const senha = 'admin' 

    it.skip('1. Realizar login na lojinha', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage()

        await loginPage.logarNaLojinha(usuario, senha)
        
        expect(await listaDeProdutosPage.obterTextoLblListaProdutos()).toEqual('Lista de Produtos')
    }),
    
    it.skip('3. Verificar cadastro de produto sem componente', async () => {
        const loginPage = new LoginPage()  
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()

        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto()

        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '600,00'

        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)
       
        const mensagem = await $('android=new UiSelector().text("Produto adicionado com sucesso")');      
        await expect(mensagem).toBeDisplayed();
    })

     it.skip('4. Validar se não é permitido o cadastro de produto com valor superior a R$ 7.000,00', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()
        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto()
        
        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '7000,01'

        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)
       
        const mensagem = await $('android=new UiSelector().text("O valor do produto deve estar entre R$ 0,01 e R$ 7.000,00")');      
        await expect(mensagem).toBeDisplayed();

    })

     it.skip('5. Validar se não é permitido o cadastro de produto com valor inferior a R$ 0,01', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()
        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto()
        
        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '0,00'

        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)
       
        const mensagem = await $('android=new UiSelector().text("O valor do produto deve estar entre R$ 0,01 e R$ 7.000,00")');      
        await expect(mensagem).toBeDisplayed();

    })

     it.skip('6.	Verificar inclusão de componente ao produto', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()
        const editarProdutoPage = new EditarProdutosPage()
        const adicionarComponentePage = new AdicionarComponentePage()
        
        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto() 
        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '652,00'
        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)

        await editarProdutoPage.clickAdicionarComponente()
        const nomeComponente = 'Marca'
        const qtdComponente = '1' 

        await adicionarComponentePage.adicionarComponente(nomeComponente, qtdComponente)
       
        const mensagem = await $('android=new UiSelector().text("Componente de produto adicionado com sucesso")');      
        await expect(mensagem).toBeDisplayed();

    })

     it.skip('7.	Verificar a adição de um componente ao cadastro de produto', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()
        const editarProdutoPage = new EditarProdutosPage()
        const adicionarComponentePage = new AdicionarComponentePage()
        
        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto() 
        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '652,00'
        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)

        await editarProdutoPage.clickAdicionarComponente()
        const nomeComponente = 'Marca'
        const qtdComponente = '1' 

        await adicionarComponentePage.adicionarComponente(nomeComponente, qtdComponente)
        await driver.pause(3000);
        await editarProdutoPage.clickSalvarEdicao()
              
        const mensagem = await $('android=new UiSelector().text("Produto alterado com sucesso")');      
        await expect(mensagem).toBeDisplayed();

    })

    it('8.	Validar a exclusão de um componente de um produto', async () => {
        const loginPage = new LoginPage()   
        const listaDeProdutosPage = new ListaDeProdutosPage() 
        const adicionarProdutoPage = new AdicionarProdutosPage()
        const editarProdutoPage = new EditarProdutosPage()
        const adicionarComponentePage = new AdicionarComponentePage()
        
        await loginPage.logarNaLojinha(usuario, senha)
        await listaDeProdutosPage.clickAdicionarProduto() 
        const nomeProduto = 'Secador'
        const corProduto = 'Azul' 
        const valorProduto = '652,00'
        await adicionarProdutoPage.adicionarProduto(nomeProduto, corProduto, valorProduto)

        await editarProdutoPage.clickAdicionarComponente()
        const nomeComponente = 'Marca'
        const qtdComponente = '1' 

        await adicionarComponentePage.adicionarComponente(nomeComponente, qtdComponente)
        await driver.pause(5000);
        await editarProdutoPage.clickExcluirComponente()

        expect(await editarProdutoPage.obterMensagemEditadoSucesso()).toEqual('Componente de produto removido com sucesso')

    })

})

